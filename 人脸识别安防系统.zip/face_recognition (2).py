import cv2
import numpy as np
import os
import dlib
import face_recognition
from PIL import Image
import pymysql
import sys
import datetime
import base64
import time
import sched
import shutil
import socket
import schedule

#����źſ���
PASS = 0;
#�����������
CON = None
#��÷��ip
ip_path = 'xxx.xxx.xxx.xxx'

known_faces_path = '/home/dengpipi/����/2'
unknown_faces_path = '/home/dengpipi/����/1'

#������������
known_person = []
all_name = []
unknown_person = []
face_locations = []
face_encodings = []
face_names = []
#�����ߴ�
size = 64
#������Ա��Ϣ��
def establish_DB(DB_path):
    for (path, dirnames, filenames) in os.walk(DB_path):
        for filename in filenames:
            if(filename.endswith('.jpg')):
                image_path = path+'/'+filename
                name,_ = os.path.splitext(filename)
                all_name.append(name)
                name1 = name
                name2 = name+'_encoding'
                #print(name)
                #print(name2)
                #load��Ϣ��ͼƬ
                name1 = face_recognition.load_image_file(image_path)
                #ͼƬ����
                name2 = face_recognition.face_encodings(name1)[0]
                known_person.append(name2)
                #print(name2)
                #i+=1
    #m=0
    #print(len(known_person))
    return known_person,all_name

def send_Pass(ip_path):
    
    HOST = ip_path
    PORT = 35600
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.connect((HOST, PORT))
    time.sleep(2)
    sock.send(b'1')
    print(sock.recv(1024).decode())
    sock.close()

    
    
    


#�������ݿ�
def connect_DB():
    conn = pymysql.connect(host='localhost',
                       port=3306,
                       user='root',
                       passwd='123',
                       db='mydatabase1',
                       charset='utf8',
                       use_unicode=True,)
    return conn
#��������ͼƬ
def save_Picture(name,pic):
    # �����α�
    cursor = conn.cursor()
 
    with open(pic, 'rb') as fp:
        data = fp.read()
        #print(data)
    cursor.execute('insert into person1(Time,People) values (%s,%s)',(name, [data]))
 
    # �ύ����Ȼ�޷������½������޸ĵ�����
    conn.commit()
 
    # �ر��α�
    cursor.close()
#��ȡ����ͼƬ
def read_picture():
    cursor = conn.cursor()

    sum = cursor.execute("select Time,People from person1")
    data = cursor.fetchall()
    print(sum)
    for i in range(sum):
        time = data[i][0]
        print(time)
        fout = open('/home/dengpipi/����/readpic/'+str(time)+'.jpg','wb')
        print(data[i][1])
        fout.write(data[i][1])
        fout.close()
        cursor.close()

#��������
def work():
    #cursor = conn.cursor()
    for (path, dirnames, filenames) in os.walk('/home/dengpipi/����/3'):
        for filename in filenames:
            if(filename.endswith('.jpg')):
                image_path = path+'/'+filename
                name,_ = os.path.splitext(filename)
                print(name)
                save_Picture(name,image_path)
                
    shutil.rmtree('/home/dengpipi/����/3')
    os.mkdir('/home/dengpipi/����/3')
    print("work has done")
#������������,����Ϊһ��
#schedule.every().day.at('00:00').do(work)  
schedule.every(5).seconds.do(work)

    
  
    
    
known_faces,names = establish_DB(known_faces_path)
print('known faces :',names)
#unknown_image = face_recognition.load_image_file('/home/dengpipi/����/2/21.jpg')
#unknown_face_encoding = face_recognition.face_encodings(unknown_image)[0]



#results = face_recognition.compare_faces(known_faces,unknown_face_encoding )

#��ȡ����ͷͼ��
video_capture = cv2.VideoCapture(0)
conn = connect_DB()
#cursor = conn.cursor()
while True:
    ret, frame = video_capture.read()

    small_frame = cv2.resize(frame, (0, 0), fx=0.25, fy=0.25)

    #Ĭ��Ϊ����δ֪����
    name = "unknown"
    #��׽����λ��
    face_locations = face_recognition.face_locations(small_frame)
    if face_locations:
        CON = 1
        #��������
        face_encodings = face_recognition.face_encodings(small_frame, face_locations)
        #print(face_locations)
        face_names = []
        for face_encoding in face_encodings:
            #����ȶ�
            match = face_recognition.compare_faces(known_faces, face_encoding)
            #print(match)
            for i in range(len(match)):
                if match[i]:
                    name = names[i]
                    PASS = 1
                    CON = 0
                #��ȡ����������
                
                
           
            #name = "unknown"
            face_names.append(name)
        if CON:
            print("luxiang ")
            cv2.imwrite('/home/dengpipi/����/3/'+str(datetime.datetime.now())+'.jpg', frame)
                  
    #print(face_names)
    #s = sched.scheduler(time.time, time.sleep)
    #s.enter(86400, 1, work,conn)
    #s.run()
    
    #���͵��������
    if PASS == 1:
        send_Pass(ip_path)
        
    
    
    #ִ�е�������
    schedule.run_pending()
    
    #��ͼ
    for (top, right, bottom, left), name in zip(face_locations, face_names):
        top *= 4
        right *= 4
        bottom *= 4
        left *= 4

        cv2.rectangle(frame, (left, top), (right, bottom), (0, 0, 255),  2)

        cv2.rectangle(frame, (left, bottom - 35), (right, bottom), (0, 0, 255), 2)
        font = cv2.FONT_HERSHEY_DUPLEX
        cv2.putText(frame, name, (left+6, bottom-6), font, 1.0, (255, 255, 255), 1)

    cv2.imshow('Video', frame)

    if cv2.waitKey(1) & 0xFF == ord('q'):
        break
conn.close()
video_capture.release()
cv2.destroyAllWindows()