import socket
import time

HOST = '127.0.0.1'
PORT = 35600
sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
sock.bind((HOST, PORT))
sock.listen(1)
pas = bytes(1).decode()
while True:
    connection, address = sock.accept()
    try:
        connection.settimeout(10)
        buf = connection.recv(1024).decode()
        if buf == 1:
            #Ƕ����Ʋ����������
            
            
            
            connection.send(b'welcome to server!')
            print('Connection success!')
        else:
            connection.send(b'please go out!')
    except socket.timeout:
        print('time out')
    connection.close()
��һ�� ��һ��